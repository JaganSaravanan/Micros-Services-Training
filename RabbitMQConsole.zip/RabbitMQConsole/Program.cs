﻿
using RabbitMQ.Client;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RabbitMQConsole
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Sender Application");
          //  IConnection connection;
            var factory = new ConnectionFactory() { HostName = "localhost" };
            using ( var connection = factory.CreateConnection())

            using (var channel = connection.CreateModel())
            {
                channel.QueueDeclare(queue: "fdmessagequeue1", durable: false, exclusive: false, autoDelete: false, arguments: null);

                Console.WriteLine("Enter message to send");

                var msg = Console.ReadLine();
                var body = Encoding.UTF8.GetBytes(msg);

                channel.BasicPublish(exchange: "", routingKey: "fdmessagequeue1", basicProperties: null, body: body);
                Console.WriteLine("[x] sent {0}", msg);
            }

            Console.WriteLine("");
            Console.ReadLine();

        }
    }
}
