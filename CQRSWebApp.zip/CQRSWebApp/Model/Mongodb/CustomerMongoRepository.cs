﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CQRSWebApp.Model.Mongodb
{
    public class CustomerMongoRepository
    {
        private const string _customerDB = "";

        public string Name { get => throw new NotImplementedException(); set => throw new NotImplementedException(); }

        public void Update(CustomerEntity customerentity)
        {
          // var filter = Builders<CustomerEntity>.Filter.Where(_=>_.Id == Customer.ID)

        }
    }

    public class CustomerEntity
    {
    }
}
