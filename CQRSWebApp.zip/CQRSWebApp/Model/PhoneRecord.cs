﻿namespace CQRSWebApp.Model
{
    public class PhoneRecord
    {
        public long id;
        public PhoneType Type { get; set; }

        public string AreaCode { get; set; }

        public int number { get; set; }
    }

    public enum PhoneType
    {
        HOMEPHONE, CELLPHONE, WORKPHONE
    }
}