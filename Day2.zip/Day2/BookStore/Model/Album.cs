﻿using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace BookStore.Model
{
    public class Album
    {
        [BsonId]
        public ObjectId _Id { get; set; }
        public long AlbumID { get; set; }
        public string AlbumName { get; set; }
        public string AlbumGenre { get; set; }
        public DateTime AlbumDate { get; set; }
        public string AlbumCreator { get; set; }
        public string AlbumLocation { get; set; }
    }
}
