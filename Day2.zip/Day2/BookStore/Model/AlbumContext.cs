﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using BookStore.Configuration;
using MongoDB.Driver;

namespace BookStore.Model
{
    public class AlbumContext : IMongodbContext
    {
        private readonly IMongoDatabase _db;

        public AlbumContext(MongoDBConfig config)
        {
            var client = new MongoClient(config.ConnectionString);
            _db = client.GetDatabase(config.Database);
        }

       // IMongoCollection<Album> IMongodbContext.AlbumList => throw new NotImplementedException();



        // public IMongoCollection<Album> AlbumList = 

        public IMongoCollection<Album> albums => _db.GetCollection<Album>("albums");

        //public IMongoCollection<Album> AlbumList => _db.GetCollection<Album>("Albums");


        //public IMongoCollection<Album> IMongodbContext.AlbumList { get => throw new NotImplementedException(); set => throw new NotImplementedException(); }
    }
}
