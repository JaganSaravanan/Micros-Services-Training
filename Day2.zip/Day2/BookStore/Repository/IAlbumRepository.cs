﻿using BookStore.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace BookStore.repository
{
    public interface IAlbumRepository
    {
        // api/[GET]
        Task<IEnumerable<Album>> GetAllAlbums();
        // api/1/[GET]
        Task<Album> GetAlbum(long id);
        // api/[POST]
        Task Create(Album book);
        // api/[PUT]
        Task<bool> Update(Album book);
        // api/1/[DELETE]
        Task<bool> Delete(long id);
        Task<long> GetNextId();
    }
}