﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using BookStore.Model;
using BookStore.repository;
using MongoDB.Bson;
using MongoDB.Driver;

namespace Bookstore.repository
{
    public class AlbumRepository : IAlbumRepository
    {
        private readonly AlbumContext _context;
        public AlbumRepository(AlbumContext context)
        {
           this._context = context;
        }
        public async Task Create(Album album)
        {
            await _context.albums.InsertOneAsync(album);
        }

        public async Task<bool> Delete(long id)
        {
            FilterDefinition<Album> filter = Builders<Album>.Filter.Eq(m => m.AlbumID, id);
            DeleteResult deleteResult = await _context
                                                .albums
                                              .DeleteOneAsync(filter);
            return deleteResult.IsAcknowledged
                && deleteResult.DeletedCount > 0;
        }

        public async Task<IEnumerable<Album>> GetAllAlbums()
        {
            return await _context
                            .albums
                            .Find(_ => true)
                            .ToListAsync();
        }

        public Task<Album> GetAlbum(long id)
        {
            FilterDefinition<Album> filter = Builders<Album>.Filter.Eq(m => m.AlbumID, id);
            return _context
                    .albums
                    .Find(filter)
                    .FirstOrDefaultAsync();
        }

        public async Task<long> GetNextId()
        {
            return await _context.albums.CountDocumentsAsync(new BsonDocument()) + 1;
        }

        public async Task<bool> Update(Album book)
        {
            ReplaceOneResult updateResult =
                await _context
                        .albums
                        .ReplaceOneAsync(
                            filter: g => g.AlbumID == book.AlbumID,
                            replacement: book);
            return updateResult.IsAcknowledged
                    && updateResult.ModifiedCount > 0;
        }
    }
}